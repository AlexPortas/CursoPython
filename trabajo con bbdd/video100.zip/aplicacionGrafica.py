import tkinter
import mysql.connector
from tkinter import *

# ----------------- conexion bbdd ---------------------------
conexion=mysql.connector.connect(host="localhost", database="app-vontade", user="root", password="")

cursor=conexion.cursor()

#cursor.execute("INSERT INTO USERS_APLICACION VALUES( null, 'Alex','PASSWORD', 2, 'Prueba', 'info@gmail.com')")

#conexion.commit()

cursor.execute("SELECT * FROM USERS_APLICACION")

productos=cursor.fetchall()

print(productos)

cursor.close()

# ------------------ Aplicación gráfica -----------------------------------

raiz=Tk()

raiz.title("Gestion usuarios aplicación")

barraMenu=Menu(raiz)

raiz.config(menu=barraMenu, width=300, height=300)

datosMenu=Menu(barraMenu, tearoff=0).add_command(label="Mostrar datos")

borrarMenu=Menu(barraMenu, tearoff=0).add_command(label="Desseleccionar usuario")

crudMenu=Menu(barraMenu, tearoff=0).add_command(label="Crear usuario")
#crudMenu.add_command(label="Modificar usuario")
#crudMenu.add_command(label="Eliminar usuario")

barraMenu.add_cascade(label="Mostrar datos", menu=datosMenu)
barraMenu.add_cascade(label="Desseleccionar", menu=borrarMenu)
barraMenu.add_cascade(label="Modificar datos", menu=crudMenu)

frame=Frame(raiz, width=1500, height=700)

frame.pack()

cuadroTextoId=Entry(frame).grid(row=0, column=1, padx=5, pady=5)

idLabel=Label(frame, text="Id: ").grid(row=0, column=0, sticky="w", padx=10)

cuadroTextoNick=Entry(frame).grid(row=1, column=1, padx=5, pady=5)

nickLabel=Label(frame, text="Nick: ").grid(row=1, column=0, sticky="w", padx=10)

cuadroTextoPwd=Entry(frame).grid(row=2, column=1, padx=5, pady=5)

contraseñaLabel=Label(frame, text="Contraseña: ").grid(row=2, column=0, sticky="w", padx=10)

cuadroTextoTUser=Entry(frame).grid(row=3, column=1, padx=5, pady=5)

tipoUserLabel=Label(frame, text="Tipo usuario: ").grid(row=3, column=0, sticky="w", padx=10)

cuadroTextoNombre=Entry(frame).grid(row=4, column=1, padx=5, pady=5)

nombreLabel=Label(frame, text="Nombre: ").grid(row=4, column=0, sticky="w", padx=10)

cuadroTextoCorreo=Entry(frame).grid(row=5, column=1, padx=5, pady=5)

correoLabel=Label(frame, text="Dirección electronica: ").grid(row=5, column=0, sticky="w", padx=10)



raiz.mainloop()