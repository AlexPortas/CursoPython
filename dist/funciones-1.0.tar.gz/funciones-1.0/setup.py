from setuptools import setup

setup(
    name = "funciones",
    version = "1.0",
    author = "Alex",
    author_mail = "",
    packages = ["modulos"]
)